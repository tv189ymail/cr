var rule = Object.assign(muban.mxpro,{
title:'Nike影视',
host:'https://www.ajeee.com',
url:'/show/fyclass/page/fypage.html',
class_name:'电影&电视剧&综艺&动漫',
class_url:'Movie&Tv&Variety&Cartoon',
class_parse:'',
});